/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author CC2_1H-11
 */
public class vlass {
    public static void main (String [] args){
        
        String [] [] a = {
            {"ben", "luna"},
            {"ben", "luna"},
            {"ben", "luna"}
        };
        
        for (int i=0; i<3; i++){
            for (int j=0; j<2; i++){
                System.out.print(a[i][j]);
            }System.out.println("");
        }
        
        
    }
}
